// public/app.js (Client-side JavaScript)

document.addEventListener("DOMContentLoaded", function () {
    const companyName = document.getElementById("company-name");
    const developerName = document.getElementById("developer-name");
    
    companyName.textContent = "Own.SA";
    developerName.textContent = "Developed by Ahmed Yasser";

    // Add phone number input event listener
    const phoneInput = document.getElementById('phone');
    phoneInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            getRecommendations();
        }
    });
});

let currentIndex = 0;
let properties = [];
let loadingTimeout;
let userData = null;

function showLoading(show = true) {
    const resultsDiv = document.getElementById('results');
    if (show) {
        resultsDiv.innerHTML = '<div class="loading">Loading recommendations...</div>';
    }
}

function showError(message) {
    const resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = `<div class="error">${message}</div>`;
}

function showUserProfile(user) {
    const profileDiv = document.getElementById('user-profile');
    if (!user) {
        profileDiv.style.display = 'none';
        return;
    }

    profileDiv.innerHTML = `
        <div class="user-info">
            <div class="user-details">
                <div class="user-contact">
                    <i class="fas fa-phone-alt"></i>
                    <span>${user.phone}</span>
                </div>
                <div class="user-preferences">
                    <i class="fas fa-list-alt"></i>
                    <span>${user.preferences}</span>
                </div>
            </div>
        </div>
    `;
    profileDiv.style.display = 'block';
}

function formatPropertyDetails(property) {
    const streetWidth = property.street_width ? `${property.street_width}m` : 'Not specified';
    return `
        <div class="property-specs">
            <div class="spec-group">
                <h4>Property Information</h4>
                <div class="spec-items">
                    <div class="spec-item">
                        <span class="spec-label">Area:</span>
                        <span class="spec-value">${property.area} m²</span>
                    </div>
                    <div class="spec-item">
                        <span class="spec-label">Type:</span>
                        <span class="spec-value">${property.property_type}</span>
                    </div>
                    <div class="spec-item">
                        <span class="spec-label">Street Width:</span>
                        <span class="spec-value">${streetWidth}</span>
                    </div>
                </div>
            </div>
            <div class="spec-group">
                <h4>Room Details</h4>
                <div class="spec-items">
                    <div class="spec-item">
                        <span class="spec-label">Bedrooms:</span>
                        <span class="spec-value">${property.number_of_bedrooms}</span>
                    </div>
                    <div class="spec-item">
                        <span class="spec-label">Living Rooms:</span>
                        <span class="spec-value">${property.number_of_livings_rooms}</span>
                    </div>
                </div>
            </div>
            <div class="spec-group">
                <h4>Location</h4>
                <div class="spec-items">
                    <div class="spec-item">
                        <span class="spec-label">District:</span>
                        <span class="spec-value">${property.district}</span>
                    </div>
                    <div class="spec-item">
                        <span class="spec-label">Direction:</span>
                        <span class="spec-value">${property.direction}</span>
                    </div>
                    <div class="spec-item">
                        <span class="spec-label">City:</span>
                        <span class="spec-value">${property.city}</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function formatPrice(price) {
    return new Intl.NumberFormat('ar-SA', {
        style: 'currency',
        currency: 'SAR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(price);
}

function getRecommendations() {
    const phone = document.getElementById('phone').value;
    if (!phone) {
        showError("Please enter your phone number");
        return;
    }

    // Show loading state
    showLoading();
    
    // Clear any existing timeout
    if (loadingTimeout) {
        clearTimeout(loadingTimeout);
    }

    // Set a timeout to show an extended loading message if it takes too long
    loadingTimeout = setTimeout(() => {
        showLoading();
        document.querySelector('.loading').innerHTML += '<br>This might take a few moments...';
    }, 3000);

    console.log("Fetching recommendations for phone:", phone);

    fetch(`http://localhost:3000/recommendations?phone=${encodeURIComponent(phone)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            clearTimeout(loadingTimeout);
            console.log("Data received:", data);
            
            if (data.error) {
                showError(data.error);
                return;
            }

            properties = data.recommendations || [];
            userData = data.user;
            
            showUserProfile(userData);
            
            if (data.message) {
                const resultsDiv = document.getElementById('results');
                resultsDiv.innerHTML = `<div class="message">${data.message}</div>`;
            }
            
            currentIndex = 0;
            displayProperty();
        })
        .catch(error => {
            clearTimeout(loadingTimeout);
            console.error('Error fetching recommendations:', error);
            showError("Failed to fetch recommendations. Please try again later.");
        });
}

function displayProperty() {
    let resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = '';

    if (properties.length === 0) {
        resultsDiv.innerHTML = "<p class='no-results'>No recommendations available.</p>";
        return;
    }

    if (currentIndex >= properties.length) {
        resultsDiv.innerHTML = `
            <div class='end-message'>
                <p>You've viewed all ${properties.length} recommendations.</p>
                <button onclick='resetRecommendations()'>Start Over</button>
            </div>`;
        return;
    }

    let property = properties[currentIndex];
    let div = document.createElement('div');
    div.className = 'property-card';
    
    // Calculate relevance class
    let relevanceClass = '';
    if (property.relevance_score) {
        if (property.relevance_score >= 80) relevanceClass = 'high-relevance';
        else if (property.relevance_score >= 60) relevanceClass = 'medium-relevance';
        else relevanceClass = 'low-relevance';
    }

    const formattedPrice = formatPrice(property.price);
    const propertySpecs = formatPropertyDetails(property);

    div.innerHTML = `
        <div class="property-header">
            <h3>${property.title}</h3>
            ${property.relevance_score ? 
                `<span class="relevance ${relevanceClass}">Relevance: ${property.relevance_score}%</span>` 
                : ''}
        </div>
        <div class="property-price">
            <span class="price-label">Price:</span>
            <span class="price-value">${formattedPrice}</span>
        </div>
        <div class="property-location">
            <p class="address">${property.address}</p>
            ${property.location ? 
                `<a href="https://www.google.com/maps?q=${property.location.replace(/[()]/g, '')}" 
                    target="_blank" class="map-link">View on Map</a>` 
                : ''}
        </div>
        ${propertySpecs}
        <div class="property-details">
            <h4>Details:</h4>
            <p>${property.details.replace(/\n/g, '<br>')}</p>
        </div>
        <div class="button-group">
            <button class="like-button" onclick="likeProperty(${property.id})">
                <i class="fas fa-thumbs-up"></i> Like
            </button>
            <button class="dislike-button" onclick="dislikeProperty(${property.id})">
                <i class="fas fa-thumbs-down"></i> Dislike
            </button>
            <button class="skip-button" onclick="nextProperty()">
                <i class="fas fa-forward"></i> Skip
            </button>
        </div>
        <div class="progress">Property ${currentIndex + 1} of ${properties.length}</div>
    `;
    resultsDiv.appendChild(div);
}

function resetRecommendations() {
    currentIndex = 0;
    displayProperty();
}

function likeProperty(propertyId) {
    const property = properties[currentIndex];
    console.log("Liked property:", propertyId, property);
    // Here you could add code to save the like to a backend API
    nextProperty();
}

function dislikeProperty(propertyId) {
    const property = properties[currentIndex];
    let comment = prompt("Please enter a reason for disliking this property (optional):");
    console.log("Disliked property:", propertyId, "Reason:", comment, property);
    // Here you could add code to save the dislike and comment to a backend API
    nextProperty();
}

function nextProperty() {
    currentIndex++;
    displayProperty();
}

// Optional: If you wish to load listings from all JSON files
function loadAllListings() {
    return Promise.all([
        fetch("/data/east of Riyadh.json").then(res => res.json()),
        fetch("/data/west of Riyadh.json").then(res => res.json()),
        fetch("/data/north of Riyadh.json").then(res => res.json()),
        fetch("/data/south of Riyadh.json").then(res => res.json())
    ]).then(results => results.flat());
}

function getRecommendationsWithAllListings() {
    loadAllListings().then(allListings => {
        properties = allListings;
        currentIndex = 0;
        displayProperty();
    });
}

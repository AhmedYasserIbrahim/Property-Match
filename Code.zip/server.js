// server.js (Backend API - Node.js)
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const { pipeline } = require("@xenova/transformers");
const districtMappings = require('./districts');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(cors());
app.use(express.static('public'));

// Listing file names for all regions
const listingFiles = [
    'east of Riyadh.json',
    'west of Riyadh.json',
    'north of Riyadh.json',
    'south of Riyadh.json'
];

// Customers CSV file path
const customersPath = path.join(__dirname, 'data', 'Customers.csv');

// Cache for property listings and customers
let listingsCache = null;
let customersCache = null;
let lastCacheUpdate = null;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

// Location translation mapping
const locationTranslations = {
    // Districts
    'tuwaiq': 'طويق',
    'malqa': 'الملقا',
    'narjis': 'النرجس',
    'yasmin': 'الياسمين',
    'nada': 'الندى',
    'wurud': 'الورود',
    'muhammadiyah': 'المحمدية',
    'taawun': 'التعاون',
    'sahafah': 'الصحافة',
    'ghadir': 'الغدير',
    'qairawan': 'القيروان',
    'rabwah': 'الربوة',
    'sulaimaniyah': 'السليمانية',
    'olaya': 'العليا',
    'masif': 'المصيف',
    'zahra': 'الزهرة',
    'rawdah': 'الروضة',
    'hamra': 'الحمراء',
    'murabba': 'المربع',
    'yarmouk': 'اليرموك',
    'khaleej': 'الخليج',
    
    // Directions
    'north': 'شمال',
    'south': 'جنوب',
    'east': 'شرق',
    'west': 'غرب',
    'central': 'وسط',
    
    // Common area descriptions
    'residential': 'سكني',
    'commercial': 'تجاري',
    'downtown': 'وسط المدينة',
    'suburb': 'ضاحية'
};

// Load Property Listings from all JSON files with caching
function loadPropertyListings() {
    if (listingsCache && lastCacheUpdate && (Date.now() - lastCacheUpdate < CACHE_DURATION)) {
        return listingsCache;
    }

    let listings = [];
    listingFiles.forEach(file => {
        const filePath = path.join(__dirname, 'data', file);
        if (fs.existsSync(filePath)) {
            try {
                const rawData = fs.readFileSync(filePath, 'utf-8');
                const data = JSON.parse(rawData);
                if (Array.isArray(data)) {
                    listings = listings.concat(data.map(listing => ({
                        ...listing,
                        source_file: file // Add source tracking
                    })));
                } else {
                    console.warn(`Data in ${file} is not an array.`);
                }
            } catch (err) {
                console.error(`Error reading ${file}:`, err);
            }
        } else {
            console.warn(`File not found: ${filePath}`);
        }
    });
    
    listingsCache = listings;
    lastCacheUpdate = Date.now();
    console.log(`Total listings loaded and cached: ${listings.length}`);
    return listings;
}

// Normalize Phone Number Function
function normalizePhoneNumber(phone) {
    // Handle scientific notation
    if (typeof phone === 'number') {
        phone = phone.toString();
    }
    // Remove any scientific notation
    if (phone.includes('E')) {
        phone = Number(phone).toFixed(0);
    }
    if (!phone.startsWith('+')) {
        phone = '+' + phone;
    }
    return phone.trim();
}

// Load Customer Data from CSV with caching
function loadCustomers() {
    if (customersCache && lastCacheUpdate && (Date.now() - lastCacheUpdate < CACHE_DURATION)) {
        return customersCache;
    }

    if (!fs.existsSync(customersPath)) {
        console.error("Customers.csv not found at", customersPath);
        return {};
    }

    try {
        const rawData = fs.readFileSync(customersPath, 'utf-8');
        let customers = {};
        
        // Parse CSV maintaining newlines in quoted fields
        const parseCSVLine = (line) => {
            const result = [];
            let cell = '';
            let inQuotes = false;
            
            for (let i = 0; i < line.length; i++) {
                const char = line[i];
                
                if (char === '"') {
                    if (inQuotes && line[i + 1] === '"') {
                        // Handle escaped quotes
                        cell += '"';
                        i++;
                    } else {
                        inQuotes = !inQuotes;
                    }
                } else if (char === ',' && !inQuotes) {
                    result.push(cell.trim());
                    cell = '';
                } else {
                    cell += char;
                }
            }
            result.push(cell.trim());
            return result;
        };

        // Split into lines while preserving newlines in quoted fields
        const lines = [];
        let currentLine = '';
        let inQuotes = false;
        
        for (let i = 0; i < rawData.length; i++) {
            const char = rawData[i];
            
            if (char === '"') {
                inQuotes = !inQuotes;
            }
            
            if (char === '\n' && !inQuotes) {
                if (currentLine.trim()) {
                    lines.push(currentLine);
                }
                currentLine = '';
            } else {
                currentLine += char;
            }
        }
        if (currentLine.trim()) {
            lines.push(currentLine);
        }

        const headers = parseCSVLine(lines[0]);

        lines.slice(1).forEach(line => {
            if (!line.trim()) return;
            
            const data = parseCSVLine(line);
            let customer = {};
            
            headers.forEach((header, index) => {
                let value = data[index] || "";
                // Handle phone number scientific notation
                if (header === 'phone' && value.includes('E')) {
                    value = Number(value).toFixed(0);
                }
                // Remove surrounding quotes if present
                if (value.startsWith('"') && value.endsWith('"')) {
                    value = value.slice(1, -1);
                }
                customer[header] = value;
            });

            // Map 'interests' to 'preferences' for compatibility
            if (customer.interests) {
                customer.preferences = customer.interests;
            }

            let normalizedPhone = normalizePhoneNumber(customer.phone);
            if (normalizedPhone) {
                customers[normalizedPhone] = customer;
                console.log(`Loaded customer: ${normalizedPhone} with preferences: ${customer.preferences}`);
            }
        });

        customersCache = customers;
        lastCacheUpdate = Date.now();
        return customers;
    } catch (error) {
        console.error("Error loading customers:", error);
        return {};
    }
}

// Parse price string to number
function parsePrice(priceStr) {
    if (!priceStr) return null;
    
    // Convert to string if number
    priceStr = priceStr.toString().trim();
    
    // Remove any currency symbols, commas and spaces
    let price = priceStr.replace(/[^\d.KkMm]/g, '');
    
    // Handle 'M' or 'm' notation (e.g., 2M = 2,000,000)
    if (priceStr.toLowerCase().includes('m')) {
        return parseFloat(price) * 1000000;
    }
    
    // Handle 'K' notation (e.g., 100K = 100,000)
    if (priceStr.toLowerCase().includes('k')) {
        return parseFloat(price) * 1000;
    }
    
    // If the number is less than 10000, assume it's in thousands
    const numericPrice = parseFloat(price);
    if (numericPrice < 10000) {
        return numericPrice * 1000;
    }
    
    return numericPrice;
}

// Extract price range from preferences
function extractPriceRange(preferences) {
    if (!preferences) return null;
    
    const prefLower = preferences.toLowerCase();
    
    // Look for two numbers that could represent a range
    const numbers = prefLower.match(/(\d+[.,]?\d*\s*[km]?)\D+(\d+[.,]?\d*\s*[km]?)/i);
    if (numbers) {
        const price1 = parsePrice(numbers[1]);
        const price2 = parsePrice(numbers[2]);
        return {
            min: Math.min(price1, price2),
            max: Math.max(price1, price2)
        };
    }
    
    // Look for a single number
    const singleNumber = prefLower.match(/(\d+[.,]?\d*\s*[km]?)/i);
    if (singleNumber) {
        const basePrice = parsePrice(singleNumber[1]);
        return {
            min: basePrice * 0.8,  // 80% of the price
            max: basePrice * 1.1   // 110% of the price
        };
    }
    
    return null;
}

// Calculate price match score
function calculatePriceMatchScore(propertyPrice, priceRange) {
    if (!propertyPrice || !priceRange) return 0;
    
    // If price is within range, give full score
    if (propertyPrice >= priceRange.min && propertyPrice <= priceRange.max) {
        return 1.0;
    }
    
    // Calculate how far outside the range the price is
    const midPrice = (priceRange.min + priceRange.max) / 2;
    const rangeSize = priceRange.max - priceRange.min;
    const distanceFromRange = propertyPrice < priceRange.min ? 
        priceRange.min - propertyPrice : 
        propertyPrice - priceRange.max;
    
    // Score decreases linearly with distance from range
    // Score becomes 0 when price is double the range size away from the range
    const maxDistance = rangeSize * 2;
    return Math.max(0, 1 - (distanceFromRange / maxDistance));
}

// Load AI Embedding Model
let model;
(async () => {
    console.log("Loading AI embedding model...");
    model = await pipeline("feature-extraction", "Xenova/all-MiniLM-L6-v2");
    console.log("Model loaded successfully.");
})();

// Load Specific Customer Data
async function loadSpecificCustomer(targetPhone) {
    if (!fs.existsSync(customersPath)) {
        console.error("Customers.csv not found at", customersPath);
        return null;
    }

    try {
        // Use the cached data if available
        const customers = loadCustomers();
        const normalizedTargetPhone = normalizePhoneNumber(targetPhone);
        
        if (customers[normalizedTargetPhone]) {
            console.log(`Found customer: ${normalizedTargetPhone} with preferences: ${customers[normalizedTargetPhone].preferences}`);
            return customers[normalizedTargetPhone];
        }
        
        console.log(`No customer found with phone: ${normalizedTargetPhone}`);
        return null;
    } catch (error) {
        console.error("Error loading customer:", error);
        return null;
    }
}

// Enhanced location matching function
function matchLocation(propertyLocation, userPreference) {
    if (!propertyLocation || !userPreference) return false;
    
    const propLoc = propertyLocation.toLowerCase();
    const prefLoc = userPreference.toLowerCase();
    
    // Try to find the district in our mappings
    const districtInfo = districtMappings.findDistrict(prefLoc);
    if (!districtInfo) return false;
    
    // Check for exact district match
    if (propLoc.includes(districtInfo.district.ar.toLowerCase()) || 
        propLoc.includes(districtInfo.districtKey.toLowerCase())) {
        return { matched: true, exact: true, region: districtInfo.regionKey };
    }
    
    // Check if property is in the same region
    const propertyDistrict = districtMappings.findDistrict(propLoc);
    if (propertyDistrict && propertyDistrict.regionKey === districtInfo.regionKey) {
        return { matched: true, exact: false, region: districtInfo.regionKey };
    }
    
    return { matched: false };
}

// Extract location from preferences
function extractLocations(preferences) {
    const prefLower = preferences.toLowerCase();
    const locations = new Set();
    const regions = new Set();
    
    // Split preference into words and check each
    const words = prefLower.split(/[\s,]+/);
    words.forEach(word => {
        const districtInfo = districtMappings.findDistrict(word);
        if (districtInfo) {
            locations.add(districtInfo.districtKey);
            regions.add(districtInfo.regionKey);
        }
    });
    
    // Also check for region names directly
    Object.keys(districtMappings.regions).forEach(regionKey => {
        const region = districtMappings.regions[regionKey];
        if (prefLower.includes(region.name.en.toLowerCase()) || 
            prefLower.includes(region.name.ar.toLowerCase())) {
            regions.add(regionKey);
        }
    });
    
    return {
        districts: Array.from(locations),
        regions: Array.from(regions)
    };
}

// Calculate price similarity score
function calculatePriceSimilarity(propertyPrice, targetPrice) {
    const priceDiff = Math.abs(propertyPrice - targetPrice);
    const percentDiff = priceDiff / targetPrice;
    
    // Exponential decay for price difference
    return Math.exp(-2 * percentDiff); // Will give 1.0 for exact match, decreasing exponentially with difference
}

// Calculate area similarity score
function calculateAreaSimilarity(propertyArea, targetArea) {
    if (!propertyArea || !targetArea) return 0;
    const areaDiff = Math.abs(propertyArea - targetArea);
    const percentDiff = areaDiff / targetArea;
    
    // Less aggressive decay for area differences
    return Math.exp(-1.5 * percentDiff); // Gentler exponential decay
}

// Extract bedroom requirements
function extractBedroomCount(preferences) {
    const prefLower = preferences.toLowerCase();
    const bedroomMatch = prefLower.match(/(\d+)\s*(?:bed|bedroom|br|b\/r|غرف|غرفة|غرف نوم)/i);
    return bedroomMatch ? parseInt(bedroomMatch[1]) : null;
}

// Enhanced property type matching
function matchPropertyType(propertyType, preferences) {
    // Handle undefined or null property type
    if (!propertyType) {
        return { matched: false, score: 0.7 }; // Base score for missing type
    }
    
    const prefLower = preferences.toLowerCase();
    const typeMatches = {
        'floor': ['floor', 'دور'],
        'apartment': ['apartment', 'flat', 'شقة', 'شقه'],
        'villa': ['villa', 'فيلا', 'فله']
    };
    
    // Convert property type to lowercase for comparison
    const normalizedPropertyType = propertyType.toString().toLowerCase();
    
    // Check for exact type matches
    let exactMatch = false;
    let matchedType = null;
    
    for (const [type, keywords] of Object.entries(typeMatches)) {
        // Check if user wants this type
        const userWantsThisType = keywords.some(keyword => prefLower.includes(keyword.toLowerCase()));
        
        if (userWantsThisType) {
            // Check if property is of this type
            const propertyIsThisType = keywords.some(keyword => 
                normalizedPropertyType.includes(keyword.toLowerCase())
            );
            
            if (propertyIsThisType) {
                exactMatch = true;
                matchedType = type;
                break;
            }
        }
    }
    
    // Scoring logic:
    // - Exact match: 1.3 (30% boost)
    // - No match but type specified: 0.7 (30% penalty)
    // - No type preference: 0.9 (slight penalty)
    
    if (exactMatch) {
        return { matched: true, score: 1.3, matchedType };
    } else if (prefLower.match(/(floor|apartment|villa|شقة|شقه|فيلا|فله|دور)/)) {
        // User specified a type but it didn't match
        return { matched: false, score: 0.7, matchedType: null };
    } else {
        // No type preference specified
        return { matched: false, score: 0.9, matchedType: null };
    }
}

// Enhanced Find Best Matches Using Direct Matching
async function findBestMatches(userPhone) {
    userPhone = normalizePhoneNumber(userPhone);
    console.log("Searching for user:", userPhone);

    const listings = loadPropertyListings();
    const user = await loadSpecificCustomer(userPhone);

    if (!user) {
        console.log("User not found in Customers.csv");
        return { 
            error: "User not found", 
            recommendations: [],
            user: null
        };
    }

    let userPreferences = user.preferences || user.interests || "";
    
    if (!userPreferences || !userPreferences.trim()) {
        console.log("No user preferences found for phone:", userPhone);
        const diverseRecommendations = getDiverseRecommendations(listings, 30);
        return {
            recommendations: diverseRecommendations,
            message: "Diverse recommendations across different areas and price ranges",
            user: {
                phone: user.phone,
                preferences: "No preferences specified"
            }
        };
    }

    try {
        const prefLowerCase = userPreferences.toLowerCase();
        
        // Extract price range
        const priceRange = extractPriceRange(userPreferences);
        
        // Extract area preferences with better pattern matching
        let areaRange = null;
        let targetArea = null;
        const areaMatch = prefLowerCase.match(/(?:area|size|space|sqm|m2|floor)\s*(?:of|is|at|about|around)?\s*([\d,.]+)(?:\s*(?:sqm|m2|square meters?)?)/i);
        if (areaMatch) {
            const areaValue = parseFloat(areaMatch[1]);
            areaRange = {
                min: areaValue * 0.9, // 10% tolerance
                max: areaValue * 1.1
            };
            targetArea = areaValue;
        }
        
        // Extract location preferences with translations
        const locations = extractLocations(userPreferences);
        
        // Extract property type preferences
        const wantsApartment = prefLowerCase.includes('apartment') || prefLowerCase.includes('شقة');
        const wantsVilla = prefLowerCase.includes('villa') || prefLowerCase.includes('فيلا');
        
        // Extract bedroom requirements
        const requiredBedrooms = extractBedroomCount(userPreferences);
        
        // Score each property
        const scoredProperties = listings.map(property => {
            let baseScore = 1.0;
            let hasLocationMatch = false;
            let hasPriceMatch = false;
            let hasAreaMatch = false;
            let hasBedroomMatch = false;
            let priceSimilarity = 0;
            let areaSimilarity = 0;
            
            // Location scoring (30% of total score)
            if (locations.districts.length > 0 || locations.regions.length > 0) {
                const propertyDistrict = property.district || '';
                const propertyDirection = property.direction || '';
                let locationMatch = false;
                let exactMatch = false;
                
                // Check each requested location
                for (const loc of locations.districts) {
                    const match = matchLocation(propertyDistrict, loc) || matchLocation(propertyDirection, loc);
                    if (match.matched) {
                        locationMatch = true;
                        if (match.exact) {
                            exactMatch = true;
                            break;
                        }
                    }
                }
                
                // If no district match but region match exists
                if (!locationMatch && locations.regions.length > 0) {
                    const propertyRegionInfo = districtMappings.findDistrict(propertyDistrict) || 
                                             districtMappings.findDistrict(propertyDirection);
                    if (propertyRegionInfo && locations.regions.includes(propertyRegionInfo.regionKey)) {
                        locationMatch = true;
                    }
                }
                
                if (exactMatch) {
                    baseScore *= 1.5; // Increased bonus for exact district match
                    hasLocationMatch = true;
                } else if (locationMatch) {
                    baseScore *= 1.3; // Regular bonus for region match
                    hasLocationMatch = true;
                }
            }
            
            // Price scoring (40% of total score)
            if (priceRange && property.price) {
                const priceMatchScore = calculatePriceMatchScore(property.price, priceRange);
                if (priceMatchScore === 1.0) {
                    hasPriceMatch = true;
                    baseScore *= 1.4; // 40% boost for exact price match
                } else {
                    baseScore *= (0.6 + priceMatchScore * 0.4); // Partial score based on how close to range
                }
            }
            
            // Area scoring (15% of total score - reduced from 30%)
            if (areaRange && targetArea && property.area) {
                areaSimilarity = calculateAreaSimilarity(property.area, targetArea);
                
                if (property.area >= areaRange.min && property.area <= areaRange.max) {
                    baseScore *= 1.15; // Reduced from 1.3
                    hasAreaMatch = true;
                    baseScore *= (1 + areaSimilarity * 0.15); // Reduced boost for close area match
                } else {
                    baseScore *= (0.85 + areaSimilarity * 0.15); // Gentler penalty for area mismatch
                }
            }
            
            // Extract bedroom requirements
            const requiredBedrooms = extractBedroomCount(userPreferences);
            
            // Property type scoring (25% of total score)
            const typeMatch = matchPropertyType(property.property_type || property.type || '', userPreferences);
            if (typeMatch.matched) {
                baseScore *= typeMatch.score;
            } else {
                baseScore *= typeMatch.score;
            }
            
            // Bedroom scoring (15% of total score - reduced from 20%)
            if (requiredBedrooms && property.bedrooms) {
                const propertyBedrooms = parseInt(property.bedrooms);
                if (propertyBedrooms === requiredBedrooms) {
                    baseScore *= 1.15; // Reduced from 1.3
                    hasBedroomMatch = true;
                } else if (propertyBedrooms === requiredBedrooms + 1) {
                    baseScore *= 1.1; // Slight boost for one extra bedroom
                    hasBedroomMatch = true;
                } else if (propertyBedrooms === requiredBedrooms - 1) {
                    baseScore *= 0.95; // Slight penalty for one less bedroom
                    hasBedroomMatch = false;
                } else if (propertyBedrooms > requiredBedrooms) {
                    baseScore *= 1.05; // Very slight boost for more bedrooms
                    hasBedroomMatch = true;
                } else {
                    baseScore *= 0.9; // Penalty for fewer bedrooms
                    hasBedroomMatch = false;
                }
            }
            
            // Exact match bonus (all criteria match)
            if (hasLocationMatch && hasPriceMatch && hasAreaMatch && 
                typeMatch.matched && hasBedroomMatch) {
                baseScore *= 1.3; // Reduced from 1.5 to prevent over-boosting
            }
            // Strong match bonus (location, price, and type match)
            else if (hasLocationMatch && hasPriceMatch && typeMatch.matched) {
                baseScore *= 1.2; // Reduced from 1.3
            }

            // Adjust final scoring to prioritize price matching more strictly
            if (!hasPriceMatch && priceRange) {
                baseScore *= 0.5; // Keep strict price matching penalty
            }

            return {
                property,
                score: baseScore,
                matchedLocation: hasLocationMatch,
                matchedPrice: hasPriceMatch,
                matchedArea: hasAreaMatch,
                matchedType: typeMatch.matched,
                matchedBedrooms: hasBedroomMatch,
                priceSimilarity: priceSimilarity * 100,
                areaSimilarity: areaSimilarity * 100
            };
        });
        
        // Enhanced sorting that prioritizes price matching
        scoredProperties.sort((a, b) => {
            // First sort by price match
            if (a.matchedPrice !== b.matchedPrice) {
                return b.matchedPrice ? 1 : -1;
            }
            
            // Then by number of other criteria matched
            const aMatches = (a.matchedLocation ? 1 : 0) + (a.matchedArea ? 1 : 0);
            const bMatches = (b.matchedLocation ? 1 : 0) + (b.matchedArea ? 1 : 0);
            
            if (aMatches !== bMatches) {
                return bMatches - aMatches;
            }
            
            // Finally by overall score
            return b.score - a.score;
        });
        
        const recommendations = scoredProperties
            .slice(0, 30)
            .map(entry => ({
                ...entry.property,
                relevance_score: Math.round(entry.score * 50),
                matched_location: entry.matchedLocation,
                matched_price: entry.matchedPrice,
                matched_area: entry.matchedArea,
                price_similarity: Math.round(entry.priceSimilarity),
                area_similarity: Math.round(entry.areaSimilarity)
            }));

        // Enhanced summary
        const summary = {
            total_matches: recommendations.length,
            price_range: priceRange ? 
                `${formatPrice(priceRange.min)} - ${formatPrice(priceRange.max)}` : null,
            target_price: priceRange ? formatPrice(priceRange.min) : null,
            target_area: targetArea ? `${targetArea} sqm` : null,
            locations_searched: locations,
            matched_preferences: [
                priceRange ? "Price" : null,
                targetArea ? "Area" : null,
                locations.districts.length > 0 || locations.regions.length > 0 ? `Location (${locations.districts.join(', ')} ${locations.regions.join(', ')})` : null,
                wantsApartment || wantsVilla ? "Property Type" : null
            ].filter(Boolean),
            exact_matches: recommendations.filter(r => r.matched_location && r.matched_price && r.matched_area).length,
            price_matches: recommendations.filter(r => r.matched_price).length,
            area_matches: recommendations.filter(r => r.matched_area).length
        };

        return {
            recommendations,
            message: `Found ${summary.exact_matches} exact matches with all criteria`,
            user: {
                phone: user.phone,
                preferences: userPreferences,
                summary
            }
        };
    } catch (error) {
        console.error("Error in recommendation process:", error);
        return { 
            error: "Error processing recommendations", 
            recommendations: [],
            user: null
        };
    }
}

// Utility function to get diverse recommendations
function getDiverseRecommendations(listings, count) {
    // Group properties by direction
    const directionGroups = {};
    listings.forEach(listing => {
        const direction = listing.direction;
        if (!directionGroups[direction]) {
            directionGroups[direction] = [];
        }
        directionGroups[direction].push(listing);
    });

    // Sort each group by a combination of factors
    Object.values(directionGroups).forEach(group => {
        group.sort((a, b) => {
            // Score based on multiple factors
            const scoreA = (1000000 / a.price) + (a.number_of_bedrooms * 0.5) + (a.area * 0.01);
            const scoreB = (1000000 / b.price) + (b.number_of_bedrooms * 0.5) + (b.area * 0.01);
            return scoreB - scoreA;
        });
    });

    // Select properties from each direction group
    const result = [];
    const groupCount = Math.ceil(count / Object.keys(directionGroups).length);
    
    Object.values(directionGroups).forEach(group => {
        result.push(...group.slice(0, groupCount));
    });

    // Shuffle and limit to desired count
    return shuffleArray(result).slice(0, count);
}

function formatPrice(price) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'SAR',
        maximumFractionDigits: 0
    }).format(price);
}

function shuffleArray(array) {
    const newArray = [...array];
    for (let i = newArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
}

// API endpoint: Get recommendations based on phone number
app.get('/recommendations', async (req, res) => {
    let userPhone = req.query.phone;
    if (!userPhone) {
        return res.status(400).json({ 
            error: "Phone number is required",
            recommendations: [] 
        });
    }
    
    try {
        const result = await findBestMatches(userPhone);
        if (result.error) {
            return res.status(400).json(result);
        }
        res.json(result);
    } catch (err) {
        console.error("Error processing recommendations:", err);
        res.status(500).json({ 
            error: "Internal Server Error",
            recommendations: []
        });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

// District mappings with regional grouping and translations
const districtMappings = {
    regions: {
        north: {
            name: { en: "Northern Riyadh", ar: "شمال الرياض" },
            districts: {
                'olaya': { ar: 'العليا', alternates: ['al-olaya', 'alolaya', 'olaia'] },
                'sulaymaniyyah': { ar: 'السليمانية', alternates: ['al-sulaymaniyyah', 'sulaimaniah'] },
                'izdihar': { ar: 'الإزدهار', alternates: ['al-izdihar', 'alizdihar'] },
                'king-fahd': { ar: 'حي الملك فهد', alternates: ['king fahd district'] },
                'masif': { ar: 'المصيف', alternates: ['al-masif', 'almasif'] },
                'murooj': { ar: 'المروج', alternates: ['al-murooj', 'almurooj'] },
                'mugharrazat': { ar: 'المغرزات', alternates: ['al-mugharrazat'] },
                'wurood': { ar: 'الورود', alternates: ['al-wurood', 'alwurud'] },
                'nakheel': { ar: 'النخيل', alternates: ['al-nakheel', 'alnakhil'] },
                'maathar-shimali': { ar: 'المعذر الشمالي', alternates: ['al-maathar al-shimali', 'north maathar'] },
                'rahmaniyya': { ar: 'الرحمانية', alternates: ['al-rahmaniyya'] },
                'muhammadiyya': { ar: 'المحمدية', alternates: ['al-muhammadiyya'] },
                'raid': { ar: 'الرائد', alternates: ['al-raid', 'alraid'] },
                'mursalat': { ar: 'المرسلات', alternates: ['al-mursalat'] },
                'nafal': { ar: 'النفل', alternates: ['al-nafal', 'alnafal'] },
                'wisham': { ar: 'الوشام', alternates: ['al-wisham'] },
                'wizarat': { ar: 'الوزارات', alternates: ['al-wizarat'] },
                'wusaita': { ar: 'الوسيطة', alternates: ['al-wusaita'] },
                'yamamah': { ar: 'اليمامة', alternates: ['al-yamamah'] },
                'king-abdullah': { ar: 'حي الملك عبدالله', alternates: ['king abdullah district'] },
                'king-salman': { ar: 'حي الملك سلمان', alternates: ['king salman neighborhood'] },
                // New districts from customer data
                'narjis': { ar: 'النرجس', alternates: ['al-narjis', 'alnarjis'] },
                'arid': { ar: 'العارض', alternates: ['al-arid', 'alarid'] },
                'malqa': { ar: 'الملقا', alternates: ['al-malqa', 'almalqa'] },
                'aqiq': { ar: 'العقيق', alternates: ['al-aqiq', 'alaqiq'] },
                'taawun': { ar: 'التعاون', alternates: ['al-taawun', 'altaawun'] },
                'muhaidib': { ar: 'المهيدب', alternates: ['al-muhaidib', 'almuhaidib'] }
            }
        },
        south: {
            name: { en: "Southern Riyadh", ar: "جنوب الرياض" },
            districts: {
                'aziziah': { ar: 'العزيزية', alternates: ['al-aziziah'] },
                'badiah': { ar: 'البادية', alternates: ['al-badiah'] },
                'bateha': { ar: 'البطحاء', alternates: ['al-bateha'] },
                'doho': { ar: 'الضحى', alternates: ['al-doho'] },
                'dubiyah': { ar: 'الضبية', alternates: ['al-dubiyah'] },
                'faisaliyyah': { ar: 'الفيصلية', alternates: ['al-faisaliyyah'] },
                'faruq': { ar: 'الفاروق', alternates: ['al-faruq'] },
                'fouta': { ar: 'الفوطة', alternates: ['al-fouta'] },
                'gadimah': { ar: 'القديمة', alternates: ['al-gadimah'] },
                'hamra': { ar: 'الحمراء', alternates: ['al-hamra'] },
                'malaz': { ar: 'الملز', alternates: ['al-malaz'] },
                'mansurah': { ar: 'المنصورة', alternates: ['al-mansurah'] },
                'margab': { ar: 'المرقب', alternates: ['al-margab'] },
                'masani': { ar: 'المصانع', alternates: ['al-masani'] },
                'murabba': { ar: 'المربع', alternates: ['al-murabba'] },
                'nasriyyah': { ar: 'الناصرية', alternates: ['al-nasriyyah'] },
                'oud': { ar: 'العود', alternates: ['al-oud'] },
                'qiri': { ar: 'القري', alternates: ['al-qiri'] },
                'rabwah': { ar: 'الربوة', alternates: ['al-rabwah'] },
                'rawdah': { ar: 'الروضة', alternates: ['al-rawdah'] },
                'salhiyah': { ar: 'الصالحية', alternates: ['al-salhiyah'] },
                'shumaisi': { ar: 'الشميسي', alternates: ['al-shumaisi'] },
                'wahah': { ar: 'الواحة', alternates: ['al-wahah'] },
                'suwaidi': { ar: 'السويدي', alternates: ['al-suwaidi'] },
                'urayja': { ar: 'العريجاء', alternates: ['al-urayja'] },
                'diplomatic-quarter': { ar: 'الحي الدبلوماسي', alternates: ['diplomatic quarter', 'dq'] },
                'dirah': { ar: 'الديرة', alternates: ['al-dirah'] },
                // New districts from customer data
                'dhahrat-laban': { ar: 'ظهرة لبن', alternates: ['dhahrat laban', 'zahrat laban'] },
                'mahdiyah': { ar: 'المهدية', alternates: ['al-mahdiyah', 'almahdiyah'] }
            }
        },
        east: {
            name: { en: "Eastern Riyadh", ar: "شرق الرياض" },
            districts: {
                'rawdah-east': { ar: 'الروضة', alternates: ['al-rawdah'] },
                'andalus': { ar: 'الأندلس', alternates: ['al-andalus'] },
                'king-faisal': { ar: 'حي الملك فيصل', alternates: ['king faisal district'] },
                'quds': { ar: 'القدس', alternates: ['al-quds'] },
                'hamra-east': { ar: 'الحمراء', alternates: ['al-hamra'] },
                'shuhada': { ar: 'الشهداء', alternates: ['ash-shuhada'] },
                'ghirnatah': { ar: 'غرناطة', alternates: ['al-ghirnatah'] },
                'qurtubah': { ar: 'قرطبة', alternates: ['al-qurtubah'] },
                'munsiyah': { ar: 'المنصية', alternates: ['al-munsiyah'] },
                'yarmuk': { ar: 'اليرموك', alternates: ['al-yarmuk'] },
                'ishbiliyah': { ar: 'إشبيلية', alternates: ['ishbiliyah'] },
                'khaleej': { ar: 'الخليج', alternates: ['al-khaleej'] },
                'nahadhah': { ar: 'النهضة', alternates: ['al-nahadhah'] },
                'maizilah': { ar: 'المعيزلة', alternates: ['al-maizilah'] },
                'qadisiyyah': { ar: 'القادسية', alternates: ['al-qadisiyyah'] },
                'rimal': { ar: 'الرمال', alternates: ['al-rimal'] },
                'sedra': { ar: 'السدرة', alternates: ['sedra'] },
                // New districts from customer data
                'badr': { ar: 'بدر', alternates: ['badr district'] },
                'saadah': { ar: 'السعادة', alternates: ['al-saadah', 'alsaadah'] }
            }
        },
        west: {
            name: { en: "Western Riyadh", ar: "غرب الرياض" },
            districts: {
                'shemaysi': { ar: 'الشميسي', alternates: ['al-shemaysi'] },
                'irqah': { ar: 'عرقة', alternates: ['irqah'] },
                'maathar': { ar: 'المعذر', alternates: ['al-maathar'] },
                'olayya-west': { ar: 'العليا', alternates: ['al-olayya'] },
                'nakheel-west': { ar: 'النخيل', alternates: ['al-nakheel'] },
                'ksu': { ar: 'جامعة الملك سعود', alternates: ['king saud university', 'ksu campus'] },
                'umm-alhamam-east': { ar: 'أم الحمام الشرقية', alternates: ['umm al-hamam east'] },
                'umm-alhamam-west': { ar: 'أم الحمام الغربية', alternates: ['umm al-hamam west'] },
                // New districts from customer data
                'tuwaiq': { ar: 'طويق', alternates: ['tuwaiq', 'twaiq'] },
                'awali': { ar: 'العوالي', alternates: ['al-awali', 'alawali'] },
                'arqah': { ar: 'عرقة', alternates: ['al-arqah', 'alarqah'] }
            }
        }
    },
    
    // Helper function to find district and its region
    findDistrict(searchTerm) {
        searchTerm = searchTerm.toLowerCase().trim();
        
        for (const [regionKey, region] of Object.entries(this.regions)) {
            for (const [districtKey, district] of Object.entries(region.districts)) {
                // Check Arabic name
                if (district.ar === searchTerm) {
                    return { district, regionKey, districtKey };
                }
                
                // Check English key
                if (districtKey === searchTerm) {
                    return { district, regionKey, districtKey };
                }
                
                // Check alternates
                if (district.alternates && district.alternates.some(alt => 
                    alt.toLowerCase() === searchTerm || 
                    searchTerm.includes(alt.toLowerCase())
                )) {
                    return { district, regionKey, districtKey };
                }
            }
        }
        
        // If no exact match, look for partial matches
        for (const [regionKey, region] of Object.entries(this.regions)) {
            for (const [districtKey, district] of Object.entries(region.districts)) {
                // Check if search term is part of any name
                if (district.ar.includes(searchTerm) || 
                    districtKey.includes(searchTerm) || 
                    (district.alternates && district.alternates.some(alt => 
                        alt.toLowerCase().includes(searchTerm)
                    ))) {
                    return { district, regionKey, districtKey, partial: true };
                }
            }
        }
        
        return null;
    },
    
    // Get all districts in a region
    getRegionDistricts(regionKey) {
        return this.regions[regionKey]?.districts || {};
    },
    
    // Get region name
    getRegionName(regionKey, language = 'en') {
        return this.regions[regionKey]?.name[language] || regionKey;
    }
};

module.exports = districtMappings; 